extends Control
## Dasar semua layar UI: margin yang menghormati area aman (notch / gesture bar) + header standar.

signal nav(target: String, args: Dictionary)
signal toast_req(msg: String)

const UI = preload("res://scripts/ui.gd")
const FX = preload("res://scripts/fx.gd")

var mc: MarginContainer
var bg: ColorRect
var _ins := Vector4.ZERO


func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false
	bg = ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.color = Color(0.039, 0.031, 0.094, 0.0)
	add_child(bg)
	mc = MarginContainer.new()
	mc.set_anchors_preset(Control.PRESET_FULL_RECT)
	mc.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(mc)
	set_insets(0, 0, 0, 0)


func set_bg_alpha(a: float) -> void:
	bg.color = Color(0.039, 0.031, 0.094, a)


func set_insets(l: float, t: float, r: float, b: float) -> void:
	_ins = Vector4(l, t, r, b)
	mc.add_theme_constant_override("margin_left", int(l) + 12)
	mc.add_theme_constant_override("margin_right", int(r) + 12)
	mc.add_theme_constant_override("margin_top", int(t) + 8)
	mc.add_theme_constant_override("margin_bottom", int(b) + 8)


func fade_in(t: float = 0.3) -> void:
	modulate.a = 0.0
	var tw := create_tween()
	tw.tween_property(self, "modulate:a", 1.0, t)


## Dipanggil main saat layar ditampilkan.
func on_enter(_args: Dictionary = {}) -> void:
	pass


## Tombol Back Android / ESC.
func on_back() -> void:
	nav.emit("menu", {})


func back_button(target: String) -> Control:
	var b := UI.btn("Back", 12, FX.s_pill(), Vector2(74, 30))
	b.set_icon(UI.icon("back"), 11, Color(1, 1, 1, 0.9), true)
	b.label.offset_left = 10.0
	b.pressed.connect(func(): nav.emit(target, {}))
	return b


## Header standar: [Back] judul (tengah) [slot kanan]. Mengembalikan HBox; judul & sub bisa diakses lewat meta.
func make_header(title: String, subtitle: String, back_target: String, right: Control = null) -> HBoxContainer:
	var h := UI.hbox(8)
	h.custom_minimum_size = Vector2(0, 34)
	var back := back_button(back_target)
	back.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(back)
	var v := UI.vbox(0)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	var t := UI.label(title, 17, FX.TX, "bold", HORIZONTAL_ALIGNMENT_CENTER)
	var s := UI.label(subtitle, 10, FX.MUT, "medium", HORIZONTAL_ALIGNMENT_CENTER)
	v.add_child(t)
	v.add_child(s)
	h.add_child(v)
	if right != null:
		right.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		h.add_child(right)
	else:
		h.add_child(UI.spacer(74, 0))
	h.set_meta("title", t)
	h.set_meta("sub", s)
	return h
