extends Control
## Dasar carousel geser (menu utama & pustaka lagu): drag dengan inersia, snap ke tengah,
## ketuk kartu tengah = buka, ketuk kartu samping = pindahkan ke tengah.
## Seluruh sentuhan ditangani di sini (tidak bergantung pada ScrollContainer Godot).

signal activated(index: int)
signal focus_changed(index: int)

var count := 0
var pos := 0.0
var target := 0.0
var pitch := 150.0
var hit_rects := {}

var _down := false
var _dragging := false
var _p0 := Vector2.ZERO
var _lastx := 0.0
var _lastt := 0
var _vel := 0.0
var _focus := -1


func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	clip_contents = false
	set_process(false)
	visibility_changed.connect(func(): set_process(is_visible_in_tree()))


func set_count(n: int) -> void:
	count = n
	target = clampf(target, 0.0, maxf(0.0, float(n - 1)))
	pos = clampf(pos, 0.0, maxf(0.0, float(n - 1)))
	queue_redraw()


func jump_to(i: int) -> void:
	pos = float(i)
	target = pos
	queue_redraw()


func center_index() -> int:
	return clampi(roundi(target), 0, maxi(0, count - 1))


func _process(delta: float) -> void:
	if not _down:
		var d := target - pos
		if absf(d) > 0.0004:
			pos += d * (1.0 - exp(-delta * 11.0))
		else:
			pos = target
	var f := clampi(roundi(pos), 0, maxi(0, count - 1))
	if f != _focus:
		_focus = f
		focus_changed.emit(f)
	queue_redraw()


func _hit_index(p: Vector2) -> int:
	var best := -1
	var bd := 99.0
	for k in hit_rects:
		var r: Rect2 = hit_rects[k]
		if r.has_point(p):
			var d := absf(float(k) - pos)
			if d < bd:
				bd = d
				best = int(k)
	return best


func _gui_input(e: InputEvent) -> void:
	if count == 0:
		return
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
		if e.pressed:
			_down = true
			_dragging = false
			_p0 = e.position
			_lastx = e.position.x
			_lastt = Time.get_ticks_msec()
			_vel = 0.0
		elif _down:
			_down = false
			if _dragging:
				var t := pos + clampf(_vel * 0.16, -2.0, 2.0)
				if absf(_vel) > 1.2:
					t = pos + signf(_vel) * maxf(1.0, absf(_vel * 0.16))
				target = clampf(roundf(t), 0.0, float(count - 1))
			else:
				var idx := _hit_index(e.position)
				if idx >= 0:
					if idx == center_index():
						Sfx.click()
						activated.emit(idx)
					else:
						Sfx.click()
						target = float(idx)
		_dragging = false
		accept_event()
	elif e is InputEventMouseButton and (e.button_index == MOUSE_BUTTON_WHEEL_UP or e.button_index == MOUSE_BUTTON_WHEEL_DOWN):
		if e.pressed:
			var dir := 1.0 if e.button_index == MOUSE_BUTTON_WHEEL_DOWN else -1.0
			target = clampf(roundf(target + dir), 0.0, float(count - 1))
			accept_event()
	elif e is InputEventMouseMotion and _down:
		if not _dragging and absf(e.position.x - _p0.x) > 9.0:
			_dragging = true
			_lastx = e.position.x
			_lastt = Time.get_ticks_msec()
		if _dragging:
			var now := Time.get_ticks_msec()
			var dx: float = e.position.x - _lastx
			pos = clampf(pos - dx / pitch, -0.4, float(count - 1) + 0.4)
			var dt := maxf(1.0, float(now - _lastt)) / 1000.0
			_vel = lerpf(_vel, -dx / pitch / dt, 0.4)
			_lastx = e.position.x
			_lastt = now
			target = pos
			accept_event()


# ---- util geometri ----

static func rr_local(w: float, h: float, r: float, seg: int = 6) -> PackedVector2Array:
	var rr := maxf(0.8, minf(r, minf(w, h) / 2.0))
	var pts := PackedVector2Array()
	var cxs := [w / 2.0 - rr, w / 2.0 - rr, -w / 2.0 + rr, -w / 2.0 + rr]
	var cys := [-h / 2.0 + rr, h / 2.0 - rr, h / 2.0 - rr, -h / 2.0 + rr]
	var a0 := [-PI / 2.0, 0.0, PI / 2.0, PI]
	for ci in 4:
		for s in seg + 1:
			var a: float = a0[ci] + (PI / 2.0) * float(s) / float(seg)
			pts.append(Vector2(float(cxs[ci]) + cos(a) * rr, float(cys[ci]) + sin(a) * rr))
	return pts


## Proyeksi 3D sederhana: skala -> rotateY -> translateZ -> perspektif.
static func proj3(p: Vector2, sc: float, theta: float, tz: float, persp: float) -> Vector3:
	var x := p.x * sc
	var y := p.y * sc
	var xr := x * cos(theta)
	var zr := -x * sin(theta) + tz
	var k := persp / maxf(1.0, persp - zr)
	return Vector3(xr * k, y * k, k)


static func bounds(pts: PackedVector2Array) -> Rect2:
	var mn := Vector2(1e9, 1e9)
	var mx := Vector2(-1e9, -1e9)
	for p in pts:
		mn = Vector2(minf(mn.x, p.x), minf(mn.y, p.y))
		mx = Vector2(maxf(mx.x, p.x), maxf(mx.y, p.y))
	return Rect2(mn, mx - mn)
