extends "res://scripts/s_base.gd"
## Menu utama: logo BeatDrop + carousel 3D (Play / Achievements / Settings). Tanpa tombol layar penuh.

const C = preload("res://scripts/consts.gd")
const WLogo = preload("res://scripts/w_logo.gd")
const WCarMenu = preload("res://scripts/w_car_menu.gd")
const TARGETS := ["lib", "ach", "settings"]

var _car
var _ver: Label
var _last := 0


func _ready() -> void:
	var col := UI.vbox(2)
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	mc.add_child(col)
	var cc := CenterContainer.new()
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var logo := WLogo.new()
	logo.setup(36)
	cc.add_child(logo)
	col.add_child(cc)
	col.add_child(UI.label("Turn any MP3 song into a rhythm game.", 13, FX.MUT, "medium", HORIZONTAL_ALIGNMENT_CENTER))
	_car = WCarMenu.new()
	_car.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_car.custom_minimum_size = Vector2(0, 150)
	col.add_child(_car)
	col.add_child(UI.label("Swipe to browse  •  tap the center card to open", 11, FX.MUT, "medium", HORIZONTAL_ALIGNMENT_CENTER))
	_ver = UI.label("", 10, Color(1, 1, 1, 0.3), "medium", HORIZONTAL_ALIGNMENT_RIGHT)
	col.add_child(_ver)
	_car.activated.connect(func(i: int): nav.emit(TARGETS[i], {}))
	_car.focus_changed.connect(func(i: int): _last = i)


func _items() -> Array:
	return [
		{"label": "Play", "icon": UI.icon("play"), "accent": Color("#ff3d81"), "g1": Color("#3d0a2a"), "g2": Color("#9a1f62"), "badge": ""},
		{"label": "Achievements", "icon": UI.icon("trophy"), "accent": Color("#ffb020"), "g1": Color("#4a3000"), "g2": Color("#c27a00"),
			"badge": "%d/%d" % [Store.achv.size(), C.ACHV.size()]},
		{"label": "Settings", "icon": UI.icon("gear"), "accent": Color("#2ee6a6"), "g1": Color("#05382c"), "g2": Color("#0f8f6c"), "badge": ""},
	]


func on_enter(_args: Dictionary = {}) -> void:
	_car.setup(_items())
	_car.jump_to(_last)
	_ver.text = "v" + Store.version_text()
	fade_in(0.35)


func on_back() -> void:
	nav.emit("quit", {})
