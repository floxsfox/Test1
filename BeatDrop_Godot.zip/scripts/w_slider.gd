extends Control
## Slider sentuh bergradien (gaya .sl di versi web). Hanya menelan gerakan bila disentuh di area slider.

signal value_changed(v: float)

var min_v := 0.0
var max_v := 1.0
var step_v := 0.0
var value := 0.0
var fill_a := Color("#ff9f1c")
var fill_b := Color("#ff3d81")

var _drag := false
const PAD := 14.0


func _init() -> void:
	custom_minimum_size = Vector2(60, 30)
	mouse_filter = Control.MOUSE_FILTER_STOP


func setup(mn: float, mx: float, st: float, v: float) -> void:
	min_v = mn
	max_v = mx
	step_v = st
	value = clampf(v, mn, mx)
	queue_redraw()


func set_colors(a: Color, b: Color) -> void:
	fill_a = a
	fill_b = b
	queue_redraw()


func set_value_silent(v: float) -> void:
	value = clampf(v, min_v, max_v)
	queue_redraw()


func nudge(delta: float) -> void:
	_apply(value + delta)


func _apply(v: float) -> void:
	var nv := clampf(v, min_v, max_v)
	if step_v > 0.0:
		nv = clampf(snappedf(nv, step_v), min_v, max_v)
	if not is_equal_approx(nv, value):
		value = nv
		queue_redraw()
		value_changed.emit(value)


func _from_x(x: float) -> void:
	var t := clampf((x - PAD) / maxf(1.0, size.x - PAD * 2.0), 0.0, 1.0)
	_apply(min_v + t * (max_v - min_v))


func _gui_input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
		_drag = e.pressed
		if e.pressed:
			_from_x(e.position.x)
		accept_event()
	elif e is InputEventMouseMotion and _drag:
		_from_x(e.position.x)
		accept_event()


func _draw() -> void:
	var cy := size.y * 0.5
	var tw := maxf(1.0, size.x - PAD * 2.0)
	var t := 0.0 if max_v <= min_v else (value - min_v) / (max_v - min_v)
	var h := 7.0
	draw_line(Vector2(PAD, cy), Vector2(PAD + tw, cy), Color(1, 1, 1, 0.1), h)
	draw_circle(Vector2(PAD, cy), h / 2.0, Color(1, 1, 1, 0.1))
	draw_circle(Vector2(PAD + tw, cy), h / 2.0, Color(1, 1, 1, 0.1))
	if t > 0.0:
		var x1 := PAD + tw * t
		draw_circle(Vector2(PAD, cy), h / 2.0, fill_a)
		var n := 18
		for i in n:
			var u0 := float(i) / float(n)
			var u1 := float(i + 1) / float(n)
			draw_line(Vector2(PAD + (x1 - PAD) * u0, cy), Vector2(PAD + (x1 - PAD) * u1, cy), fill_a.lerp(fill_b, (u0 + u1) * 0.5 * t), h)
	var kp := Vector2(PAD + tw * t, cy)
	var kc := fill_a.lerp(fill_b, t)
	draw_circle(kp, 15.0, Color(kc.r, kc.g, kc.b, 0.22))
	draw_circle(kp, 11.0, kc)
	draw_circle(kp, 9.0, Color("#ffffff"))
	draw_circle(kp, 6.0, Color("#e9e4ff"))
