extends "res://scripts/s_base.gd"
## Layar hasil: nilai besar, skor, statistik Perfect/Great/Good/Miss, PLAY AGAIN / Menu.

const C = preload("res://scripts/consts.gd")
const WRank = preload("res://scripts/w_rank.gd")

var _info: Label
var _rank
var _score: Label
var _hp: Label
var _note: Label
var _vals: Array = []


func _ready() -> void:
	set_bg_alpha(0.86)
	var main := UI.hbox(26)
	main.alignment = BoxContainer.ALIGNMENT_CENTER
	mc.add_child(main)
	# kiri
	var left := UI.vbox(2)
	left.alignment = BoxContainer.ALIGNMENT_CENTER
	left.custom_minimum_size = Vector2(300, 0)
	main.add_child(left)
	_info = UI.label("", 13, FX.MUT, "medium", HORIZONTAL_ALIGNMENT_CENTER)
	left.add_child(_info)
	var rc := CenterContainer.new()
	rc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_rank = WRank.new()
	rc.add_child(_rank)
	left.add_child(rc)
	_score = UI.label("0", 44, FX.TX, "bold", HORIZONTAL_ALIGNMENT_CENTER)
	left.add_child(_score)
	_hp = UI.label("", 12, FX.MUT, "medium", HORIZONTAL_ALIGNMENT_CENTER)
	left.add_child(_hp)
	_note = UI.label("", 12, FX.MUT, "medium", HORIZONTAL_ALIGNMENT_CENTER)
	left.add_child(_note)
	# kanan
	var right := UI.vbox(8)
	right.alignment = BoxContainer.ALIGNMENT_CENTER
	right.custom_minimum_size = Vector2(330, 0)
	main.add_child(right)
	var stats := UI.hbox(6)
	right.add_child(stats)
	var names := ["Perfect", "Great", "Good", "Miss"]
	var cols := [FX.GOLD, FX.GREEN, FX.TX, FX.RED]
	for i in 4:
		var b := UI.card({"c1": FX.rgba(54, 44, 128, 0.55), "c2": FX.rgba(20, 16, 50, 0.7), "ang": 155.0, "bcol": FX.rgba(150, 125, 255, 0.3),
				"bw": 1.0, "rad": 12.0}, 6, 8, 6, 8)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.custom_minimum_size = Vector2(72, 58)
		var v := UI.vbox(0)
		v.alignment = BoxContainer.ALIGNMENT_CENTER
		var nv := UI.label("0", 20, cols[i], "bold", HORIZONTAL_ALIGNMENT_CENTER)
		v.add_child(nv)
		v.add_child(UI.label(String(names[i]), 11, FX.MUT, "medium", HORIZONTAL_ALIGNMENT_CENTER))
		b.body.add_child(v)
		stats.add_child(b)
		_vals.append(nv)
	var br := UI.hbox(8)
	var st := FX.s_primary()
	st["shine"] = true
	var again := UI.btn("PLAY AGAIN", 14, st, Vector2(190, 42), Color.WHITE, 2)
	again.pressed.connect(func(): nav.emit("retry", {}))
	br.add_child(again)
	var songs := UI.btn("Songs", 13, FX.s_ghost(), Vector2(66, 42))
	songs.pressed.connect(func(): nav.emit("lib", {}))
	br.add_child(songs)
	var mn := UI.btn("Menu", 13, FX.s_ghost(), Vector2(66, 42))
	mn.pressed.connect(func(): nav.emit("menu", {}))
	br.add_child(mn)
	right.add_child(br)


func on_enter(a: Dictionary = {}) -> void:
	var run: Dictionary = a.get("run", {})
	var g: String = String(run.get("grade", "F"))
	var failed: bool = bool(run.get("failed", false))
	_info.text = "%s · %s%s" % [String(run.get("name", "")), C.DIFF_N[int(run.get("diff", 0))], "  ·  FAILED" if failed else ""]
	_rank.set_rank(g, 84)
	_rank.slam()
	var sc := int(run.get("score", 0))
	_score.text = "0"
	var tw := create_tween()
	tw.tween_method(func(v: float): _score.text = C.fmt_int(int(v)), 0.0, float(sc), 1.1).set_trans(Tween.TRANS_QUART).set_ease(Tween.EASE_OUT)
	_hp.text = "HP %d%%" % roundi(float(run.get("hp", 0.0)))
	var pre := "New best! " if bool(a.get("new_best", false)) else ""
	_note.text = pre + "Accuracy %.1f%% · Max combo %d" % [float(run.get("acc", 0.0)) * 100.0, int(run.get("maxC", 0))]
	var cnt: Array = run.get("cnt", [0, 0, 0, 0])
	var idx := [2, 1, 0, 3]
	for i in 4:
		(_vals[i] as Label).text = str(int(cnt[idx[i]]))
	fade_in(0.25)
	if failed:
		Sfx.play("miss")
	else:
		Sfx.play("fanfare")


func on_back() -> void:
	nav.emit("menu", {})
