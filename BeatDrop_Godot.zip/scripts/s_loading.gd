extends "res://scripts/s_base.gd"
## Layar loading: analisis lagu (thread latar) dengan progress.

const WBar = preload("res://scripts/w_bar.gd")

var _title: Label
var _stage: Label
var _bar
var _hint: Label


func _ready() -> void:
	set_bg_alpha(0.97)
	var col := UI.vbox(10)
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	mc.add_child(col)
	_title = UI.label("Loading...", 22, FX.TX, "bold", HORIZONTAL_ALIGNMENT_CENTER)
	col.add_child(_title)
	_stage = UI.label("", 13, FX.MUT, "medium", HORIZONTAL_ALIGNMENT_CENTER)
	col.add_child(_stage)
	var c := CenterContainer.new()
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_bar = WBar.new()
	_bar.custom_minimum_size = Vector2(300, 10)
	c.add_child(_bar)
	col.add_child(c)
	_hint = UI.label("", 11, Color(1, 1, 1, 0.4), "medium", HORIZONTAL_ALIGNMENT_CENTER)
	col.add_child(_hint)


func on_enter(args: Dictionary = {}) -> void:
	_title.text = String(args.get("title", "Loading..."))
	_stage.text = String(args.get("stage", ""))
	_hint.text = String(args.get("hint", ""))
	_bar.value = float(args.get("p", 0.0))
	fade_in(0.2)


func set_progress(p: float, stage_text: String) -> void:
	_bar.value = p
	_stage.text = stage_text


func on_back() -> void:
	pass
