extends Control
## Huruf nilai besar (F..S+) bergradien vertikal + cahaya, seperti .rank di versi web.

const FX = preload("res://scripts/fx.gd")

const SHADER := """
shader_type canvas_item;
uniform vec4 top = vec4(1.0, 0.97, 0.87, 1.0);
uniform vec4 bot = vec4(1.0, 0.79, 0.23, 1.0);
uniform float rainbow = 0.0;
const vec3 P[6] = vec3[6](vec3(1.0, 0.239, 0.506), vec3(1.0, 0.624, 0.11), vec3(1.0, 0.9, 0.3), vec3(0.18, 0.9, 0.65), vec3(0.227, 0.627, 1.0), vec3(1.0, 0.239, 0.506));
void fragment() {
	vec4 base = COLOR;
	vec3 c = mix(top.rgb, bot.rgb, clamp(UV.y * 1.1 - 0.05, 0.0, 1.0));
	if (rainbow > 0.5) {
		float t = fract(UV.x * 0.5 + UV.y * 0.3 + TIME * 0.35) * 5.0;
		int i = int(floor(t));
		c = mix(P[i], P[i + 1], fract(t));
	}
	COLOR = vec4(c, base.a);
}
"""

const LOOKS := {
	"F": [Color("#c7cbd6"), Color("#7c8296"), Color(0.49, 0.51, 0.59, 0.45)],
	"C": [Color("#fff3b0"), Color("#ffd94a"), Color(1.0, 0.85, 0.29, 0.5)],
	"B": [Color("#b8ffd9"), Color("#2ee6a6"), Color(0.18, 0.9, 0.65, 0.5)],
	"B+": [Color("#e2fff0"), Color("#2ee6a6"), Color(0.18, 0.9, 0.65, 0.6)],
	"A": [Color("#fff2c0"), Color("#ffb700"), Color(1.0, 0.72, 0.0, 0.55)],
	"A+": [Color("#fff8dd"), Color("#ffc93a"), Color(1.0, 0.72, 0.0, 0.65)],
	"S": [Color("#ffb3c2"), Color("#ff2d55"), Color(1.0, 0.18, 0.33, 0.65)],
	"S+": [Color("#ffffff"), Color("#ff9acb"), Color(1.0, 0.31, 0.63, 0.7)],
}

var _glow: Label
var _front: Label
var _mat: ShaderMaterial


func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_glow = Label.new()
	_front = Label.new()
	for l in [_glow, _front]:
		l.add_theme_font_override("font", FX.font("bolditalic"))
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		l.set_anchors_preset(Control.PRESET_FULL_RECT)
		l.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(l)
	var sh := Shader.new()
	sh.code = SHADER
	_mat = ShaderMaterial.new()
	_mat.shader = sh
	_front.material = _mat
	_glow.add_theme_constant_override("outline_size", 16)
	resized.connect(func(): pivot_offset = size / 2.0)


func set_rank(g: String, px: int = 84) -> void:
	var look: Array = LOOKS.get(g, LOOKS["F"])
	_front.text = g
	_glow.text = g
	for l in [_glow, _front]:
		l.add_theme_font_size_override("font_size", px)
	_front.add_theme_color_override("font_color", Color.WHITE)
	_glow.add_theme_color_override("font_color", look[2])
	_glow.add_theme_color_override("font_outline_color", look[2])
	_mat.set_shader_parameter("top", look[0])
	_mat.set_shader_parameter("bot", look[1])
	_mat.set_shader_parameter("rainbow", 1.0 if g == "S+" else 0.0)
	custom_minimum_size = Vector2(px * 1.7, px * 1.25)


## Animasi "slam": mulai besar & transparan lalu menghantam ke ukuran normal.
func slam() -> void:
	pivot_offset = size / 2.0
	scale = Vector2(2.2, 2.2)
	modulate.a = 0.0
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(self, "scale", Vector2.ONE, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(self, "modulate:a", 1.0, 0.22)
