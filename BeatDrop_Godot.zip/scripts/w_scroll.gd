extends Control
## Area scroll vertikal buatan sendiri, ramah sentuhan:
##  - menerima gesek dari anak-anaknya (anak harus ber-mouse_filter PASS/IGNORE),
##  - ada deadzone, inersia, dan bar indikator.
## Taruh konten di `content` (VBoxContainer).

var content: VBoxContainer
var scroll := 0.0

var _vel := 0.0
var _down := false
var _dragging := false
var _p0 := Vector2.ZERO
var _last := Vector2.ZERO
var _bar_a := 0.0
const DEADZONE := 8.0


func _init() -> void:
	clip_contents = true
	mouse_filter = Control.MOUSE_FILTER_PASS
	content = VBoxContainer.new()
	content.mouse_filter = Control.MOUSE_FILTER_PASS
	content.add_theme_constant_override("separation", 10)
	add_child(content)
	resized.connect(_layout)
	content.minimum_size_changed.connect(_layout)
	set_process(false)


func _max_scroll() -> float:
	return maxf(0.0, content.get_combined_minimum_size().y - size.y)


func _layout() -> void:
	var h := maxf(size.y, content.get_combined_minimum_size().y)
	content.size = Vector2(size.x, h)
	scroll = clampf(scroll, 0.0, _max_scroll())
	content.position = Vector2(0.0, -scroll)
	queue_redraw()


func scroll_to_top() -> void:
	scroll = 0.0
	_vel = 0.0
	_layout()


func _gui_input(e: InputEvent) -> void:
	if e is InputEventMouseButton:
		if e.button_index == MOUSE_BUTTON_LEFT:
			if e.pressed:
				_down = true
				_dragging = false
				_p0 = e.position
				_last = e.position
				_vel = 0.0
			else:
				_down = false
				if _dragging:
					set_process(true)
				_dragging = false
		elif e.button_index == MOUSE_BUTTON_WHEEL_UP and e.pressed:
			_vel = -420.0
			set_process(true)
		elif e.button_index == MOUSE_BUTTON_WHEEL_DOWN and e.pressed:
			_vel = 420.0
			set_process(true)
	elif e is InputEventMouseMotion and _down:
		if not _dragging and absf(e.position.y - _p0.y) > DEADZONE:
			_dragging = true
		if _dragging:
			var dy: float = _last.y - e.position.y
			scroll = clampf(scroll + dy, 0.0, _max_scroll())
			_vel = lerpf(_vel, dy * 60.0, 0.5)
			content.position.y = -scroll
			_bar_a = 1.0
			queue_redraw()
			accept_event()
		_last = e.position


func _process(delta: float) -> void:
	if _down:
		return
	if absf(_vel) > 8.0:
		scroll = clampf(scroll + _vel * delta, 0.0, _max_scroll())
		_vel *= pow(0.02, delta)
		content.position.y = -scroll
		_bar_a = 1.0
	else:
		_vel = 0.0
		_bar_a = maxf(0.0, _bar_a - delta * 2.5)
	queue_redraw()
	if _vel == 0.0 and _bar_a <= 0.0:
		set_process(false)


func _draw() -> void:
	var m := _max_scroll()
	if m <= 1.0 or _bar_a <= 0.01:
		return
	var th := maxf(24.0, size.y * size.y / (size.y + m))
	var y := (size.y - th) * (scroll / m)
	var r := Rect2(size.x - 5.0, y, 3.0, th)
	draw_rect(r, Color(1, 1, 1, 0.35 * _bar_a))
