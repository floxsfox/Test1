extends RefCounted
## Helper UI (satuan = px CSS, tinggi layar logis 400). Tema global memakai font Chakra Petch.

const FX = preload("res://scripts/fx.gd")
const WPanel = preload("res://scripts/w_panel.gd")
const WBtn = preload("res://scripts/w_btn.gd")
const WSlider = preload("res://scripts/w_slider.gd")
const WSwitch = preload("res://scripts/w_switch.gd")
const WScroll = preload("res://scripts/w_scroll.gd")

static var _theme: Theme = null
static var _icons := {}


static func icon(name: String) -> Texture2D:
	if not _icons.has(name):
		_icons[name] = load("res://assets/ui/" + name + ".png")
	return _icons[name]


static func theme() -> Theme:
	if _theme != null:
		return _theme
	var t := Theme.new()
	t.default_font = FX.font("medium")
	t.default_font_size = 14
	t.set_font("font", "Label", FX.font("medium"))
	t.set_font_size("font_size", "Label", 14)
	t.set_color("font_color", "Label", FX.TX)
	t.set_font("font", "Button", FX.font("bold"))
	t.set_font_size("font_size", "Button", 14)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.09, 0.075, 0.2, 0.9)
	sb.border_color = FX.LINE
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(12)
	sb.set_content_margin_all(8)
	for n in ["normal", "hover", "pressed", "disabled"]:
		t.set_stylebox(n, "Button", sb)
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_color("font_color", "Button", FX.TX)
	var ps := StyleBoxFlat.new()
	ps.bg_color = Color(1, 1, 1, 0.1)
	ps.set_corner_radius_all(6)
	t.set_stylebox("background", "ProgressBar", ps)
	var pf := StyleBoxFlat.new()
	pf.bg_color = FX.PINK
	pf.set_corner_radius_all(6)
	t.set_stylebox("fill", "ProgressBar", pf)
	_theme = t
	return t


static func label(text: String, size: int = 14, color: Color = FX.TX, kind: String = "medium", align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_override("font", FX.font(kind))
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.horizontal_alignment = align
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


static func spaced(text: String, size: int, color: Color, spacing: int, kind: String = "bold") -> Label:
	var l := label(text, size, color, kind)
	var f := FontVariation.new()
	f.base_font = FX.font(kind)
	f.spacing_glyph = spacing
	l.add_theme_font_override("font", f)
	return l


## Tombol bergaya. st = salah satu FX.s_* (Dictionary).
static func btn(text: String, size: int, st: Dictionary, min_size: Vector2 = Vector2(0, 36), color: Color = FX.TX, spacing: int = 0) -> WBtn:
	var b := WBtn.new()
	b.custom_minimum_size = min_size
	b.style(st)
	if text != "":
		b.set_text(text, size, color, "bold", spacing)
	return b


static func card(st: Dictionary, pad_l: float = 12.0, pad_t: float = 10.0, pad_r: float = 12.0, pad_b: float = 10.0) -> WPanel:
	var p := WPanel.new()
	p.style(st)
	p.make_body(pad_l, pad_t, pad_r, pad_b)
	return p


static func hbox(sep: int = 8) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", sep)
	h.mouse_filter = Control.MOUSE_FILTER_PASS
	return h


static func vbox(sep: int = 8) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", sep)
	v.mouse_filter = Control.MOUSE_FILTER_PASS
	return v


static func spacer(w: float = 0.0, h: float = 0.0, expand: bool = false) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(w, h)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if expand:
		c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		c.size_flags_vertical = Control.SIZE_EXPAND_FILL
	return c


static func icon_rect(name: String, px: float, tint: Color = Color.WHITE) -> TextureRect:
	var r := TextureRect.new()
	r.texture = icon(name)
	r.custom_minimum_size = Vector2(px, px)
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	r.modulate = tint
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return r


static func clear_children(n: Node) -> void:
	for c in n.get_children():
		n.remove_child(c)
		c.queue_free()
