extends Control
## Intro: memutar assets/intro.ogv (hasil konversi dari intro.mp4) menutupi layar, lalu FADE OUT ke menu.
## Ketuk untuk melewati. Bila video tidak ada/gagal, tampil logo sederhana.

signal finished

const VIDEO_PATH := "res://assets/intro.ogv"
const VIDEO_AR := 16.0 / 9.0
const FX = preload("res://scripts/fx.gd")
const WLogo = preload("res://scripts/w_logo.gd")

var _video: VideoStreamPlayer = null
var _logo = null
var _done := false
var _age := 0.0
var _fb_timer := 0.0


func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false
	var bg := ColorRect.new()
	bg.color = Color.BLACK
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	resized.connect(_cover)
	set_process(false)


func start() -> void:
	visible = true
	modulate.a = 1.0
	_done = false
	_age = 0.0
	set_process(true)
	if ResourceLoader.exists(VIDEO_PATH):
		var vs = load(VIDEO_PATH)
		if vs is VideoStream:
			_video = VideoStreamPlayer.new()
			_video.stream = vs
			_video.expand = true
			_video.mouse_filter = Control.MOUSE_FILTER_IGNORE
			_video.finished.connect(_finish)
			add_child(_video)
			_cover()
			_video.play()
			_fb_timer = 9.0
			return
	_fallback()


func _fallback() -> void:
	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_logo = WLogo.new()
	_logo.setup(48)
	cc.add_child(_logo)
	add_child(cc)
	cc.modulate.a = 0.0
	var tw := create_tween()
	tw.tween_property(cc, "modulate:a", 1.0, 0.6)
	tw.tween_interval(0.9)
	tw.tween_callback(_finish)
	_fb_timer = 4.0
	Sfx.play("unlock")


## Isi layar penuh (object-fit: cover) untuk video 16:9.
func _cover() -> void:
	if _video == null:
		return
	var ca := size.x / maxf(1.0, size.y)
	var w := size.x
	var h := size.x / VIDEO_AR
	if ca < VIDEO_AR:
		h = size.y
		w = size.y * VIDEO_AR
	_video.position = (size - Vector2(w, h)) / 2.0
	_video.size = Vector2(w, h)


func _process(delta: float) -> void:
	_age += delta
	_fb_timer -= delta
	if _fb_timer < 0.0 and not _done:
		_finish()


func _gui_input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.pressed and _age > 0.5:
		_finish()
		accept_event()


func _finish() -> void:
	if _done:
		return
	_done = true
	finished.emit()          # main menampilkan menu di bawah overlay ini
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(self, "modulate:a", 0.0, 0.7)
	if _video != null:
		tw.tween_property(_video, "volume_db", -50.0, 0.6)
	tw.chain().tween_callback(func():
		visible = false
		set_process(false)
		if _video != null:
			_video.stop()
			_video.queue_free()
			_video = null)
