extends RefCounted
## Gaya visual BeatDrop (port dari CSS index.html): warna, font, dan shader panel.
## Satuan UI = "px CSS" (tinggi layar logis 400), sama dengan desain web asli.

const TX := Color("#f5f2ff")
const MUT := Color("#9e98cc")
const LINE := Color("#2d2757")
const PINK := Color("#ff3d81")
const VIOLET := Color("#7c5cff")
const GREEN := Color("#2ee6a6")
const BLUE := Color("#3aa0ff")
const GOLD := Color("#ffd24a")
const AMBER := Color("#ffb020")
const RED := Color("#ff4d6d")

const PANEL_SHADER := """
shader_type canvas_item;

uniform vec2 psize = vec2(100.0, 100.0);
uniform float pad = 0.0;
uniform vec4 c1 = vec4(0.2, 0.15, 0.4, 1.0);
uniform vec4 c2 = vec4(0.1, 0.08, 0.2, 1.0);
uniform vec4 cm = vec4(0.0);
uniform float mid = 0.55;
uniform float ang = 2.356;
uniform vec4 bcol = vec4(1.0, 1.0, 1.0, 0.2);
uniform float bw = 1.0;
uniform float rad = 16.0;
uniform vec4 gcol = vec4(0.0);
uniform float gsz = 0.0;
uniform float hi = 0.0;
uniform float lip = 0.0;
uniform vec4 scol = vec4(0.0);
uniform vec2 soff = vec2(0.0, 0.0);
uniform float sblur = 1.0;
uniform float shine = -5.0;

float sdr(vec2 p, vec2 b, float r) {
	vec2 q = abs(p) - b + vec2(r);
	return length(max(q, vec2(0.0))) + min(max(q.x, q.y), 0.0) - r;
}

void fragment() {
	vec4 base = COLOR;
	vec2 px = UV * psize;
	vec2 c = psize * 0.5;
	vec2 hb = max(psize * 0.5 - vec2(pad), vec2(1.0));
	float r = min(rad, min(hb.x, hb.y));
	float d = sdr(px - c, hb, r);
	float fa = clamp(0.5 - d, 0.0, 1.0);
	vec2 dir = vec2(cos(ang), sin(ang));
	float ext = abs(dir.x) * hb.x * 2.0 + abs(dir.y) * hb.y * 2.0;
	float t = clamp(0.5 + dot(px - c, dir) / max(ext, 1.0), 0.0, 1.0);
	vec4 col = mix(c1, c2, t);
	if (cm.a > 0.0) {
		if (t < mid) {
			col = mix(c1, cm, t / mid);
		} else {
			col = mix(cm, c2, (t - mid) / (1.0 - mid));
		}
	}
	float ty = px.y - (c.y - hb.y);
	col.rgb += vec3(hi) * (1.0 - smoothstep(0.0, 2.5, ty));
	float by = (c.y + hb.y) - px.y;
	float lipk = lip * (1.0 - smoothstep(4.0, 5.5, by));
	col.rgb = mix(col.rgb, vec3(0.0, 0.157, 0.47), 0.4 * lipk);
	if (shine > -4.0) {
		float sx = (px.x - (c.x - hb.x)) / (hb.x * 2.0) - (px.y - c.y) / (hb.x * 2.0) * 0.36;
		float sh = 1.0 - smoothstep(0.0, 0.2, abs(sx - shine));
		col.rgb += vec3(0.5) * sh;
	}
	float ring = smoothstep(-bw - 0.5, -bw + 0.5, d);
	float ba = bcol.a * ring;
	vec4 fc;
	fc.a = ba + col.a * (1.0 - ba);
	fc.rgb = (bcol.rgb * ba + col.rgb * col.a * (1.0 - ba)) / max(fc.a, 0.0001);
	fc.a *= fa;
	float gd = max(d, 0.0);
	float g = 0.0;
	if (gsz > 0.0) {
		g = gcol.a * exp(-gd / max(gsz * 0.35, 0.001)) * (1.0 - smoothstep(gsz * 0.7, gsz, gd));
	}
	float sd = sdr(px - c - soff, hb, r);
	float sa = scol.a * (1.0 - smoothstep(-sblur, sblur + 0.001, sd));
	float a01 = g + sa * (1.0 - g);
	vec3 c01 = (gcol.rgb * g + scol.rgb * sa * (1.0 - g)) / max(a01, 0.0001);
	float ao = fc.a + a01 * (1.0 - fc.a);
	vec3 co = (fc.rgb * fc.a + c01 * a01 * (1.0 - fc.a)) / max(ao, 0.0001);
	COLOR = vec4(co * base.rgb, ao * base.a);
}
"""

const ROUND_SHADER := """
shader_type canvas_item;
uniform vec2 psize = vec2(100.0, 100.0);
uniform float rad = 20.0;
float sdr(vec2 p, vec2 b, float r) {
	vec2 q = abs(p) - b + vec2(r);
	return length(max(q, vec2(0.0))) + min(max(q.x, q.y), 0.0) - r;
}
void fragment() {
	vec2 px = UV * psize;
	float d = sdr(px - psize * 0.5, psize * 0.5, min(rad, min(psize.x, psize.y) * 0.5));
	COLOR.a *= clamp(0.5 - d, 0.0, 1.0);
}
"""

static var _shader: Shader = null
static var _round: Shader = null
static var _fonts := {}


static func panel_shader() -> Shader:
	if _shader == null:
		_shader = Shader.new()
		_shader.code = PANEL_SHADER
	return _shader


static func round_shader() -> Shader:
	if _round == null:
		_round = Shader.new()
		_round.code = ROUND_SHADER
	return _round


## kind: "regular" | "medium" | "semibold" | "bold" | "bolditalic"
static func font(kind: String = "medium") -> Font:
	if not _fonts.has(kind):
		var names := {
			"regular": "ChakraPetch-Regular", "medium": "ChakraPetch-Medium", "semibold": "ChakraPetch-SemiBold",
			"bold": "ChakraPetch-Bold", "bolditalic": "ChakraPetch-BoldItalic",
		}
		_fonts[kind] = load("res://assets/fonts/" + String(names.get(kind, "ChakraPetch-Medium")) + ".ttf")
	return _fonts[kind]


static func rgba(r: float, g: float, b: float, a: float) -> Color:
	return Color(r / 255.0, g / 255.0, b / 255.0, a)


# ----- gaya siap pakai (diterjemahkan dari CSS) -----

static func s_panel() -> Dictionary:
	return {"c1": rgba(54, 44, 128, 0.62), "c2": rgba(14, 10, 36, 0.78), "ang": 155.0, "bcol": rgba(150, 125, 255, 0.4),
			"bw": 1.0, "rad": 20.0, "scol": Color(0, 0, 0, 0.5), "soff": Vector2(0, 10), "sblur": 22.0, "hi": 0.08}


static func s_pill() -> Dictionary:
	return {"c1": rgba(20, 16, 44, 0.72), "c2": rgba(20, 16, 44, 0.72), "bcol": Color(1, 1, 1, 0.22), "bw": 1.0, "rad": 12.0}


static func s_row(on: bool, accent: Color = VIOLET) -> Dictionary:
	if on:
		return {"c1": accent.darkened(0.78), "c2": accent.darkened(0.7), "ang": 100.0, "bcol": accent, "bw": 2.0, "rad": 14.0,
				"gcol": Color(accent.r, accent.g, accent.b, 0.4), "gsz": 14.0}
	return {"c1": rgba(23, 19, 50, 0.85), "c2": rgba(14, 11, 34, 0.9), "ang": 100.0, "bcol": LINE, "bw": 2.0, "rad": 14.0}


static func s_primary() -> Dictionary:
	return {"c1": PINK, "c2": VIOLET, "ang": 90.0, "bcol": Color(1, 1, 1, 0.0), "bw": 0.0, "rad": 999.0, "hi": 0.22,
			"gcol": Color(1.0, 0.24, 0.5, 0.45), "gsz": 14.0}


static func s_start() -> Dictionary:
	return {"c1": Color("#38e6ff"), "cm": Color("#3a8bff"), "mid": 0.55, "c2": Color("#6f5cff"), "ang": 100.0,
			"bcol": Color(1, 1, 1, 0.3), "bw": 1.0, "rad": 16.0, "hi": 0.3, "lip": 1.0,
			"gcol": Color(0.22, 0.6, 1.0, 0.5), "gsz": 16.0}


static func s_ghost() -> Dictionary:
	return {"c1": Color(0, 0, 0, 0.0), "c2": Color(0, 0, 0, 0.0), "bcol": rgba(120, 100, 220, 0.55), "bw": 1.0, "rad": 999.0}


static func s_opt(on: bool) -> Dictionary:
	if on:
		return {"c1": rgba(255, 61, 129, 0.34), "c2": rgba(124, 92, 255, 0.34), "ang": 135.0, "bcol": PINK, "bw": 2.0, "rad": 14.0,
				"gcol": Color(1.0, 0.24, 0.5, 0.45), "gsz": 12.0}
	return {"c1": rgba(23, 19, 50, 0.85), "c2": rgba(14, 11, 34, 0.9), "ang": 100.0, "bcol": LINE, "bw": 2.0, "rad": 14.0}
