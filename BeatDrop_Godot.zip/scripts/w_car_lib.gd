extends "res://scripts/w_carousel.gd"
## Carousel pustaka lagu (menu "Play"): kartu sampul tinggi, kartu tengah menyala pink + "TAP TO PLAY".
## Geometri mengikuti CSS asli: perspektif bersama 1000 (titik 50% / 40%), rotateY(o * -44deg),
## translateZ(-min(a,3)*120), scale(1 - min(a,2)*.05), opasitas max(.35, 1 - a*.22).

const FX = preload("res://scripts/fx.gd")
const C = preload("res://scripts/consts.gd")

var items: Array = []     # {id, name, meta, grade, best, tex}


func setup(arr: Array) -> void:
	items = arr
	set_count(arr.size())


func _draw() -> void:
	hit_rects.clear()
	if items.is_empty():
		return
	var ch := clampf(size.y - 4.0, 150.0, 480.0)
	var cw := ch * 0.76
	pitch = cw * 0.8
	var ox := size.x * 0.5
	var oy := size.y * 0.4
	var cyc := size.y * 0.5
	var order: Array = []
	for i in items.size():
		order.append(i)
	order.sort_custom(func(a, b): return absf(float(a) - pos) > absf(float(b) - pos))
	var local := rr_local(cw, ch, 22.0, 7)
	var fb := FX.font("bold")
	var fm := FX.font("medium")
	for i in order:
		var o := float(i) - pos
		var a := absf(o)
		if a > 3.4:
			continue
		var it: Dictionary = items[i]
		var theta := deg_to_rad(clampf(o, -1.0, 1.0) * -44.0)
		var tz := -minf(a, 3.0) * 120.0
		var sc := 1.0 - minf(a, 2.0) * 0.05
		var alpha := maxf(0.35, 1.0 - a * 0.22)
		var f := clampf(1.0 - a, 0.0, 1.0)
		var x0 := o * pitch
		var ycen := cyc - oy
		var tex: Texture2D = it.get("tex")
		var pts := PackedVector2Array()
		var cols := PackedColorArray()
		var uvs := PackedVector2Array()
		var dir := Vector2(sin(deg_to_rad(135.0)), -cos(deg_to_rad(135.0)))
		var ext := absf(dir.x) * cw + absf(dir.y) * ch
		for p in local:
			# proyeksi bersama: titik kartu relatif terhadap titik hilang
			var qx := (x0 * 1.0 + p.x * sc * cos(theta))
			var zr := -p.x * sc * sin(theta) + tz
			var k := 1000.0 / maxf(1.0, 1000.0 - zr)
			pts.append(Vector2(ox + qx * k, oy + (ycen + p.y * sc) * k))
			if tex != null:
				uvs.append(Vector2(0.5 + (p.x / cw) * 0.76, (p.y + ch / 2.0) / ch))
				cols.append(Color(1, 1, 1, alpha))
			else:
				var t := clampf(0.5 + p.dot(dir) / ext, 0.0, 1.0)
				var c := Color("#3b2c86").lerp(Color("#ff3d81"), t)
				c.a = alpha
				cols.append(c)
		hit_rects[i] = bounds(pts)
		var closed := pts.duplicate()
		closed.append(pts[0])
		if f > 0.0:
			for gi in 5:
				draw_polyline(closed, Color(1.0, 0.24, 0.5, (0.07 + 0.10 * f) * (1.0 - float(gi) * 0.18) * alpha), 3.0 + float(gi) * 5.0, true)
		if tex != null:
			draw_polygon(pts, cols, uvs, tex)
		else:
			draw_polygon(pts, cols)
			# ikon nada di tengah sampul
			var kn := 1000.0 / maxf(1.0, 1000.0 - tz)
			var ni := cw * 0.42 * kn * sc
			var pc := Vector2(ox + x0 * kn, oy + (ycen - ch * 0.12 * sc) * kn)
			draw_texture_rect(_note_tex(), Rect2(pc - Vector2(ni, ni) / 2.0, Vector2(ni, ni)), false, Color(1, 1, 1, 0.55 * alpha))
		# gelap di bawah untuk teks
		var y_cut := ch * 0.12
		var cap := _bottom_cap(cw, ch, 22.0, y_cut)
		var cp := PackedVector2Array()
		var cc := PackedColorArray()
		for p in cap:
			var qx2 := (x0 + p.x * sc * cos(theta))
			var zr2 := -p.x * sc * sin(theta) + tz
			var k2 := 1000.0 / maxf(1.0, 1000.0 - zr2)
			cp.append(Vector2(ox + qx2 * k2, oy + (ycen + p.y * sc) * k2))
			var u := clampf((p.y - y_cut) / (ch / 2.0 - y_cut), 0.0, 1.0)
			cc.append(Color(0.03, 0.024, 0.094, 0.94 * u * alpha))
		draw_polygon(cp, cc)
		# border
		var bcol := Color(1.0, 0.24, 0.5, 1.0).lerp(Color(1, 1, 1, 0.14), 1.0 - f)
		bcol.a = lerpf(0.14, 1.0, f) * alpha
		draw_polyline(closed, bcol, 1.0 + 1.0 * f, true)
		# teks
		var cq := Vector2(ox + x0 * (1000.0 / maxf(1.0, 1000.0 - tz)), oy + ycen * (1000.0 / maxf(1.0, 1000.0 - tz)))
		var kc := 1000.0 / maxf(1.0, 1000.0 - tz)
		var s := kc * sc
		var nm: String = it["name"]
		var fs := maxi(8, int(round(13.0 * s)))
		nm = _fit(fb, nm, fs, cw * 0.88 * s)
		var tw := fb.get_string_size(nm, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		draw_string(fb, cq + Vector2(-tw / 2.0, (ch / 2.0 - 44.0) * s), nm, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1, 1, 1, alpha))
		var ms: String = it["meta"]
		var fs2 := maxi(7, int(round(9.5 * s)))
		var tw2 := fm.get_string_size(ms, HORIZONTAL_ALIGNMENT_LEFT, -1, fs2).x
		draw_string(fm, cq + Vector2(-tw2 / 2.0, (ch / 2.0 - 30.0) * s), ms, HORIZONTAL_ALIGNMENT_LEFT, -1, fs2, Color(0.8, 0.78, 0.95, alpha))
		var bs: int = int(it.get("best", 0))
		if bs > 0:
			var bt := "Best " + C.fmt_int(bs)
			var tw3 := fb.get_string_size(bt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs2).x
			draw_string(fb, cq + Vector2(-tw3 / 2.0, (ch / 2.0 - 17.0) * s), bt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs2, Color(1.0, 0.82, 0.29, alpha))
		if f > 0.55:
			var ht := "TAP TO PLAY"
			var tw4 := fb.get_string_size(ht, HORIZONTAL_ALIGNMENT_LEFT, -1, fs2).x
			draw_string(fb, cq + Vector2(-tw4 / 2.0, (ch / 2.0 - 5.0) * s), ht, HORIZONTAL_ALIGNMENT_LEFT, -1, fs2, Color(1.0, 0.45, 0.7, alpha * f))
		# lencana nilai terbaik (kiri atas)
		var g: String = it.get("grade", "")
		if g != "":
			var gc := C.grade_color(g)
			var bw := 30.0
			var bpos := Vector2(-cw / 2.0 + 8.0 + bw / 2.0, -ch / 2.0 + 8.0 + bw / 2.0)
			var br := rr_local(bw, bw, 9.0, 4)
			var bp := PackedVector2Array()
			for p in br:
				var pp := p + bpos
				var qx3 := (x0 + pp.x * sc * cos(theta))
				var zr3 := -pp.x * sc * sin(theta) + tz
				var k3 := 1000.0 / maxf(1.0, 1000.0 - zr3)
				bp.append(Vector2(ox + qx3 * k3, oy + (ycen + pp.y * sc) * k3))
			draw_colored_polygon(bp, Color(0.03, 0.024, 0.094, 0.78 * alpha))
			var bclosed := bp.duplicate()
			bclosed.append(bp[0])
			draw_polyline(bclosed, Color(gc.r, gc.g, gc.b, alpha), 1.5, true)
			var fb2 := FX.font("bolditalic")
			var gs := maxi(8, int(round((12.0 if g.length() > 1 else 14.0) * s)))
			var gw := fb2.get_string_size(g, HORIZONTAL_ALIGNMENT_LEFT, -1, gs).x
			var bq := Vector2(ox + (x0 + bpos.x * sc * cos(theta)) * kc, oy + (ycen + bpos.y * sc) * kc)
			draw_string(fb2, bq + Vector2(-gw / 2.0, gs * 0.36), g, HORIZONTAL_ALIGNMENT_LEFT, -1, gs, Color(gc.r, gc.g, gc.b, alpha))


var _note: Texture2D = null


func _note_tex() -> Texture2D:
	if _note == null:
		_note = load("res://assets/ui/note.png")
	return _note


func _fit(font: Font, txt: String, fs: int, maxw: float) -> String:
	if font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x <= maxw:
		return txt
	var s := txt
	while s.length() > 1 and font.get_string_size(s + "...", HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x > maxw:
		s = s.substr(0, s.length() - 1)
	return s + "..."


## Poligon bagian bawah kartu (di bawah y_cut) dengan sudut bawah membulat.
func _bottom_cap(w: float, h: float, r: float, y_cut: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	var rr := minf(r, minf(w, h) / 2.0)
	pts.append(Vector2(-w / 2.0, y_cut))
	for n in 7:
		var a := PI - (PI / 2.0) * float(n) / 6.0
		pts.append(Vector2(-w / 2.0 + rr + cos(a) * rr, h / 2.0 - rr + sin(a) * rr))
	for n in 7:
		var b := PI / 2.0 - (PI / 2.0) * float(n) / 6.0
		pts.append(Vector2(w / 2.0 - rr + cos(b) * rr, h / 2.0 - rr + sin(b) * rr))
	pts.append(Vector2(w / 2.0, y_cut))
	return pts
