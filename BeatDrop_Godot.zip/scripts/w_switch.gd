extends Control
## Saklar on/off (gaya .tg di versi web): hijau-biru saat aktif.

signal toggled(on: bool)

var on := false
var _k := 0.0
var _sb_off := StyleBoxFlat.new()


func _init() -> void:
	custom_minimum_size = Vector2(52, 28)
	mouse_filter = Control.MOUSE_FILTER_PASS
	_sb_off.bg_color = Color(1, 1, 1, 0.16)
	_sb_off.set_corner_radius_all(14)
	_sb_off.anti_aliasing = true
	set_process(false)


func set_on(v: bool, emit: bool = false) -> void:
	on = v
	set_process(true)
	if emit:
		toggled.emit(on)


func toggle() -> void:
	set_on(not on, true)


func _process(delta: float) -> void:
	var tgt := 1.0 if on else 0.0
	_k = move_toward(_k, tgt, delta * 9.0)
	queue_redraw()
	if is_equal_approx(_k, tgt):
		set_process(false)


func _draw() -> void:
	var r := Rect2(Vector2.ZERO, Vector2(52.0, 28.0))
	draw_style_box(_sb_off, r)
	if _k > 0.01:
		var col := Color("#2ee6a6").lerp(Color("#3aa0ff"), 0.0)
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(col.r, col.g, col.b, _k)
		sb.set_corner_radius_all(14)
		sb.anti_aliasing = true
		draw_style_box(sb, r)
	draw_circle(Vector2(14.0 + 24.0 * _k, 14.0), 11.0, Color.WHITE)
