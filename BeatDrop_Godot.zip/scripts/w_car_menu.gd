extends "res://scripts/w_carousel.gd"
## Carousel menu utama: 3 kartu kaca berwarna (Play / Achievements / Settings), kartu tengah menyala.
## Geometri mengikuti CSS asli: rotateY(o * -38deg), translateZ(-min(a,2)*70), scale(1 - min(a,1.5)*.1), perspektif 700.

const FX = preload("res://scripts/fx.gd")

var items: Array = []     # {label, icon, accent, g1, g2, badge}
var card_w := 245.0
var card_h := 107.0


func _init() -> void:
	pitch = 304.0


func setup(arr: Array) -> void:
	items = arr
	set_count(arr.size())


func _draw() -> void:
	hit_rects.clear()
	if items.is_empty():
		return
	var cy := size.y * 0.5
	var cw := card_w
	var ch := card_h
	pitch = cw * 1.24
	var order: Array = []
	for i in items.size():
		order.append(i)
	order.sort_custom(func(a, b): return absf(float(a) - pos) > absf(float(b) - pos))
	var font_b := FX.font("bold")
	var local := rr_local(cw, ch, 16.0, 6)
	for i in order:
		var o := float(i) - pos
		var a := absf(o)
		if a > 2.6:
			continue
		var it: Dictionary = items[i]
		var theta := deg_to_rad(clampf(o, -1.0, 1.0) * -38.0)
		var tz := -minf(a, 2.0) * 70.0
		var sc := 1.0 - minf(a, 1.5) * 0.1
		var cx := size.x * 0.5 + o * pitch
		var f := clampf(1.0 - a, 0.0, 1.0)
		var accent: Color = it["accent"]
		var g1: Color = it["g1"]
		var g2: Color = it["g2"]
		var pts := PackedVector2Array()
		var cols := PackedColorArray()
		var dir := Vector2(sin(deg_to_rad(145.0)), -cos(deg_to_rad(145.0)))
		var ext := absf(dir.x) * cw + absf(dir.y) * ch
		for p in local:
			var q := proj3(p, sc, theta, tz, 700.0)
			pts.append(Vector2(cx + q.x, cy + q.y))
			var t := clampf(0.5 + p.dot(dir) / ext, 0.0, 1.0)
			var c := g1.lerp(g2, t)
			c.a = 0.96
			cols.append(c)
		hit_rects[i] = bounds(pts)
		# glow (kartu terfokus lebih terang)
		var closed := pts.duplicate()
		closed.append(pts[0])
		for gi in 5:
			var wgl := 4.0 + float(gi) * 5.0
			draw_polyline(closed, Color(accent.r, accent.g, accent.b, (0.05 + 0.10 * f) * (1.0 - float(gi) * 0.17)), wgl, true)
		draw_polygon(pts, cols)
		# kilau atas
		var ta := Vector2(-cw / 2.0 + 14.0, -ch / 2.0 + 1.5)
		var tb := Vector2(cw / 2.0 - 14.0, -ch / 2.0 + 1.5)
		var q1 := proj3(ta, sc, theta, tz, 700.0)
		var q2 := proj3(tb, sc, theta, tz, 700.0)
		draw_line(Vector2(cx + q1.x, cy + q1.y), Vector2(cx + q2.x, cy + q2.y), Color(1, 1, 1, 0.16 + 0.1 * f), 1.5, true)
		var bcol := accent.lerp(Color.WHITE, f * 0.85)
		draw_polyline(closed, Color(bcol.r, bcol.g, bcol.b, 0.75 + 0.25 * f), 1.2 + 1.3 * f, true)
		# isi kartu
		var cq := proj3(Vector2.ZERO, sc, theta, tz, 700.0)
		var s := cq.z * sc
		var ic: Texture2D = it["icon"]
		var isz := 30.0 * s
		var ctr := Vector2(cx + cq.x, cy + cq.y)
		draw_texture_rect(ic, Rect2(ctr + Vector2(-isz / 2.0, -ch * 0.5 * s * 0.62), Vector2(isz, isz)), false, Color(1, 1, 1, 0.55 + 0.45 * f))
		var fsz := maxi(8, int(round(14.0 * s)))
		var lbl: String = it["label"]
		var tw := font_b.get_string_size(lbl, HORIZONTAL_ALIGNMENT_LEFT, -1, fsz).x
		draw_string(font_b, ctr + Vector2(-tw / 2.0, ch * 0.5 * s * 0.50), lbl, HORIZONTAL_ALIGNMENT_LEFT, -1, fsz, Color(1, 1, 1, 0.8 + 0.2 * f))
		var badge: String = it.get("badge", "")
		if badge != "":
			var bq := proj3(Vector2(cw / 2.0 - 14.0, -ch / 2.0 + 16.0), sc, theta, tz, 700.0)
			var bs := maxi(7, int(round(9.5 * s)))
			var bw := FX.font("medium").get_string_size(badge, HORIZONTAL_ALIGNMENT_LEFT, -1, bs).x
			draw_string(FX.font("medium"), Vector2(cx + bq.x - bw, cy + bq.y), badge, HORIZONTAL_ALIGNMENT_LEFT, -1, bs, Color("#ffd24a"))
